from django.apps import AppConfig


class FreetimesConfig(AppConfig):
    name = 'freetimes'
