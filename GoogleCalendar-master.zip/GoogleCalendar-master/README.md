# GoogleCalendar
Tries to figure out list of times that are available from your google calendar 


(NOTE: It's not completed yet)
